#include<iostream>
using namespace std;
int main()
{
	int n, i, arr[50], j, temp,ch;
	cout<<"Enter total number of elements :\n";
	cin>>n;
	cout<<"Enter "<<n<<" numbers :\n";
	for(i=0; i<n; i++)
	{
		cin>>arr[i];
	}
	
	cout<<"1:bubble sort\n2:insertion sort\n3:selection sort\n";
	cout<<"enter your ch\n";
	cin>>ch;
	//for(int g=0;g<=ch;g++)
	//{
		switch(ch)
		{
			case 1:								//BUBBLE SORT
			{
				for(i=0; i<(n-1); i++)
				{
					for(j=0; j<(n-i-1); j++)
					{
						if(arr[j]>arr[j+1])
						{
							temp=arr[j];
							arr[j]=arr[j+1];
							arr[j+1]=temp;
						}
					}
				}
				cout<<"Sorted list is :\n\n";
				for(i=0; i<n; i++)
				{
					cout<<arr[i]<<" ";
				}
				cout<<"\n";
			break;
			}
			case 2:								//INSETTION SORT
			{
				int ele;
				for(i=1;i<n;i++)
				{
					ele=arr[i];
					j=i-1;
					while(j>=0 && arr[j]>ele)
					{
						arr[j+1]=arr[j];
						--j;
					}
					arr[j+1]=ele;
				}
				cout<<"Sorted list is :\n\n";
				for(i=0; i<n; i++)
				{
					cout<<arr[i]<<" ";
				}
				cout<<"\n";
			break;
			}
			case 3:
			{
			}
		}
	//}
return 0;
}
